(() => {
  const canvas = document.createElement('canvas');
  canvas.className = 'aurora-canvas';
  document.body.prepend(canvas);
  const ctx = canvas.getContext('2d');
  let w = 0, h = 0, particles = [];
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function resize() {
    const ratio = Math.min(window.devicePixelRatio || 1, 2);
    w = canvas.width = window.innerWidth * ratio;
    h = canvas.height = window.innerHeight * ratio;
    canvas.style.width = window.innerWidth + 'px'; canvas.style.height = window.innerHeight + 'px';
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    particles = Array.from({ length: Math.min(70, Math.floor(window.innerWidth / 20)) }, () => ({
      x: Math.random() * window.innerWidth, y: Math.random() * window.innerHeight,
      r: Math.random() * 1.6 + .3, vx: (Math.random() - .5) * .18, vy: (Math.random() - .5) * .18,
      a: Math.random() * .45 + .12
    }));
  }
  function frame() {
    const cw = window.innerWidth, ch = window.innerHeight;
    ctx.clearRect(0, 0, cw, ch);
    for (const p of particles) {
      p.x += p.vx; p.y += p.vy;
      if (p.x < -10) p.x = cw + 10; if (p.x > cw + 10) p.x = -10;
      if (p.y < -10) p.y = ch + 10; if (p.y > ch + 10) p.y = -10;
      ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(105,230,255,${p.a})`; ctx.fill();
    }
    if (!reduce) requestAnimationFrame(frame);
  }
  resize(); window.addEventListener('resize', resize); frame();

  const scanline = document.createElement('div'); scanline.className = 'scanline'; document.body.append(scanline);
  document.querySelectorAll('.nav-link[href="login.html"]').forEach(link => link.addEventListener('click', () => {
    localStorage.removeItem('user'); localStorage.removeItem('token');
  }));
  document.querySelectorAll('button').forEach(button => button.addEventListener('click', () => {
    button.classList.remove('command-flash'); void button.offsetWidth; button.classList.add('command-flash');
  }));
})();
